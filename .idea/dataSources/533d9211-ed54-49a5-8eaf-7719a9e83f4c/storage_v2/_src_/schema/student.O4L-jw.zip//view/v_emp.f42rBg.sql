CREATE VIEW v_emp AS
  SELECT
    `student`.`emp`.`empno`    AS `empno`,
    `student`.`emp`.`ename`    AS `ename`,
    `student`.`emp`.`job`      AS `job`,
    `student`.`emp`.`mgr`      AS `mgr`,
    `student`.`emp`.`hiredate` AS `hiredate`,
    `student`.`emp`.`sal`      AS `sal`,
    `student`.`emp`.`comm`     AS `comm`,
    `student`.`emp`.`deptno`   AS `deptno`
  FROM `student`.`emp`;

